# testing and development __init__.py

__author__ = ', '.join([
    'Michael E. Vinyard'
])
__email__ = ', '.join([
    'vinyard@g.harvard.edu',
])

from ._dev_libraries import _load_development_libraries as load_dev_libs