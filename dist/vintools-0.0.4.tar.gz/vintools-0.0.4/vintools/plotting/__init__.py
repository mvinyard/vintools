# plotting

from ._fig_presets import _single_fig_presets as presets
from ._make_data_gif import _make_gif as make_gif
from ._color_pallette_preset import vin_colors